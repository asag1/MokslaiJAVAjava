# Java programavimo pagrindai

### Teorija
- [Java OOP teorija 1](JavaBasics.pdf)
- [Java OOP teorija 2](JavaBasics2.pdf)
- [Java OOP teorija 3](JavaBasics3.pdf)

### Užduotys
- [Užduotys](exercises/readme.md)

### Naudingos nuorodos
- https://www.w3schools.com/java/
- [Java code convention](https://www.oracle.com/technetwork/java/codeconvtoc-136057.html)
