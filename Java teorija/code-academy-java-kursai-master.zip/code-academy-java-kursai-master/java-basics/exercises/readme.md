# Užduotys

- [Exercises.pdf](Exercises.pdf)
- [Polimorfizmo užduotis](polymorphism-exercises.md)
