package utils;

public enum RcCommand {

    UP, DOWN, LEFT, RIGHT, ACCELERATE, DECELERATE
}
