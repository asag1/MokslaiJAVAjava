# Boulingo žaidimo testavimas

1. Atsisiųskite sukurtą projektą iš [repozitorijos](unit-testing)
2. Jums reikia baigti įgyvendinti `BowlingGame` klasę, taip, kad jos pagalba būtų galima imituoti boulingo žaidimą
3. Klasė turėtų būti įgyventina atsižvelgiant į tikras [boulingo taisykles](http://neokaunas.lt/boulingo-taisykles/)
4. Parašykite *unit* testus, įrodančius, kad klasės įgyvendinimas atitinka boulingo taisykles
