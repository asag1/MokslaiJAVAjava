public interface OfficialIdProvider {

    String generateOfficialId(Person person);
}
