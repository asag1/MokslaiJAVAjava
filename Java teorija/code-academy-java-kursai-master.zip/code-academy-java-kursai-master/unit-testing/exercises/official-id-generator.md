# Asmens kodo generatoriaus testavimas

1. Atsisiųskite jau sukurtą projektą iš [repozitorijos](officialidgenerator)
2. Sukurkite klasę `LithuanianOfficialIdProvider`, kuri įgyvendintų `OfficialIdProvider` sąsąją
3. Jūsų sukurta klasė turėtų įgyvendinti metodą, kuris priimtų `Person` tipo objektą ir grąžintų asmens kodą, atitinkantį Lietuvos valstybės formatą
4. Parašykite *unit* testus, įrodančius, kad visais įmanomais atvejais asmens kodai generuojami teisingai 
