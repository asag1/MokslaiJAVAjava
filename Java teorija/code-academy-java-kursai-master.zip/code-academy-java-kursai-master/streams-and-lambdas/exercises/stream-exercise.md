# Srautų užduotis
1. Atsisiųskite [projektą](src/) su užduočiai reikalingais failais
2. Projekte sukurkite naują klasę `DefaultShopService`, įgyvendinančią `ShopService`sąsąją
3. `ShopService` metodų įgyvendinimui naudokite kolekciją, gaunamą iš `ShopRepository.getShop()` metodo 
4. Kad gautumėte reikiamus rezultatus, manipuliuokite kolekcijos elementais pasitelkdami srautus
