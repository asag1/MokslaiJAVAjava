
## Užduotys: Java Date Time API

## Nr. 1

### Užduotis

- Sukurti programą, kuri paskaičiuotų Jūsų tikslų amžių metais, mėnesiais ir dienomis.
- Raskite visų Jūsų gmtadienių savaitės dienas. Sugrupuokite ir atspausdinkite kurią savaitės dieną kiek kartų šventėte gimtadienį.

## Nr. 2

### Užduotis

1960-06-10 yra laikoma magiška data, nes jos dienos skaičių padauginus iš mėnesio skaičiaus gauname metų skaičių. 
Originaliai `6/10/60`.
Parašyti programą, kuriai galime nurodyti datų rėžius. Duotuose rėžiuose surasti visas magiškas datas.