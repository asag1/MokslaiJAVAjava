1. Atsisiųskite [Git](https://git-scm.com/downloads)
2. Susikurkite Github paskyrą [Github](https://github.com/) puslapyje
3. Sukurkite naują repozitoriją Git puslapyje
4. Nukopijuokite sukurtą repozitoriją į lokalią direktoriją
5. Savo repozitorijoje sukurkite Java programėlę `Hello World!`
6. *Commitinkite* pakeitimus ir nusiųskite į nuotolinį serverį
7. Įsitikinkite, kad pakeitimai matomi Git puslapyje
8. Pakeiskite repozitorijos failus Git puslapyje
9. Parsisiųskite pakeitimus į lokalią repozitoriją
10. Sukurkite atšaką pavadinimu `feature/test` ir pasikeiskite į ją
11. Pakeiskite programėlę kad ji spausdintų `Hello <jūsų vardas>!` vietoje `Hello world!` 
12. *Commitinkite* pakeitimus
13. Įsitikinkite, kad išvedamas tekstas atšakose skiriasi
14. Nusiųskite pakeitimus į nuotolinį serverį
15. Prijunkite `feature/test` atšaką prie `master` atšakos
16. Pakeiskite tą patį failą `master` ir `feature/test` atšakose ir vėl prijunkite prie `master` atšakos
17. Grąžinkite `master` atšaką į *commitą*, kuriame spausdinama `Hello World!`
18. Ištrinkite `feature/test` atšaką
19. Ištrinkite `Hello World!` programėlę iš `master` atšakos
20. Sukelkite savo praktikos užduotis į sukurtą repozitoriją
21. Įsitikinkite, kad užduotis yra nuotoliniame serveryje
22. Atsiųskite savo repozitorijos adresą man (Tadui) į *slack'ą* bei pridėkite mane kaip *colaboratorių*
23. Susiraskite sau idomių repozitorijų [naršydami](https://github.com/explore) Git
