public enum DnsProvider {
    GOOGLE, CLOUDFLARE;
}
