package lt.codeacademy.learn;

public interface Saugykla {

    void saugotiInfo(Info info);
    Info rastiInfo(int id);
    Info rastiInfo(String zodis);

}
