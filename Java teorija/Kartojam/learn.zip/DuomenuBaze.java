package lt.codeacademy.learn;

import java.util.HashMap;

public class DuomenuBaze implements Saugykla {

    private HashMap<Integer, Info> mapas;

    public DuomenuBaze() {
        this.mapas = new HashMap<>();
    }

    @Override
    public void saugotiInfo(Info info) {
        mapas.put(info.getId(), info);
        System.out.println("Issaugota i DB");
    }

    @Override
    public Info rastiInfo(int id) {
        System.out.println("Rasta DB pagal id");
        return mapas.get(id);
    }

    @Override
    public Info rastiInfo(String zodis) {
        for (Info infoIsMapo : mapas.values()) {
            if (infoIsMapo.getTekstas().contains(zodis)) {
                System.out.println("Rasta DB pagal zodi");
                return infoIsMapo;
            }
        }
        return null;
    }
}
