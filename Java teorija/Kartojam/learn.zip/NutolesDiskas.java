package lt.codeacademy.learn;

import java.util.ArrayList;

public class NutolesDiskas implements Saugykla {

    private ArrayList<Info> listas;

    public NutolesDiskas() {
        listas = new ArrayList<>();
    }

    @Override
    public void saugotiInfo(Info info) {
        listas.add(info);
        System.out.println("Issaugota nutolusiame diske");
    }

    @Override
    public Info rastiInfo(int id) {
        for (Info infoIsListo : listas) {
            if (infoIsListo.getId() == id) {
                System.out.println("Rasta nutolusiame diske paga id");
                return infoIsListo;
            }
        }
        return null;
    }

    @Override
    public Info rastiInfo(String zodis) {
        for (Info infoIsListo : listas) {
            if (infoIsListo.getTekstas().contains(zodis)) {
                System.out.println("Rasta nutolusiame diske paga zodi");
                return infoIsListo;
            }
        }
        return null;
    }
}
