package lt.codeacademy.learn;


public class Main {

    public static void main(String[] args) {

        Saugykla saugykla1 = new DuomenuBaze();
        Saugykla saugykla2 = new NutolesDiskas();

        Info info1 = new Info(1, "Hello");
        Info info2 = new Info(2, "Vakaras");
        Info info3 = new Info(3, "Java");
        Info info4 = new Info(4, "Sausainis");

        Main main = new Main();

        main.saugoti(saugykla1, info1);
        main.saugoti(saugykla1, info2);
        main.saugoti(saugykla1, info3);
        main.saugoti(saugykla2, info1);
        main.saugoti(saugykla2, info2);
        main.saugoti(saugykla2, info4);

        main.rastiPagalId(saugykla1, info1.getId());
        main.rastiPagalZodi(saugykla1, info1.getTekstas());
        main.rastiPagalId(saugykla2, info3.getId());
        main.rastiPagalZodi(saugykla2, "Sau");

    }

    public void saugoti(Saugykla saugykla, Info info) {
        saugykla.saugotiInfo(info);
    }

    public void rastiPagalId(Saugykla saugykla, int id) {
        saugykla.rastiInfo(id);
    }

    public void rastiPagalZodi(Saugykla saugykla, String zodis) {
        saugykla.rastiInfo(zodis);
    }
}


